let games = [];
let view = 'home';
let current = null;
const $ = (id) => document.getElementById(id);
const initial = (t) => t.charAt(0).toUpperCase();

function fmtTime(min) {
  if (!min) return 'Mai giocato';
  const h = Math.floor(min / 60), m = min % 60;
  return h ? `${h} h ${m} min` : `${m} min`;
}
function fmtDate(iso) { return iso ? new Date(iso).toLocaleDateString('it-IT') : '—'; }

function filtered(list) {
  const q = $('search').value.trim().toLowerCase();
  return list.filter(g => g.title.toLowerCase().includes(q));
}
function sortedAll() { return [...games].sort((a, b) => a.title.localeCompare(b.title, 'it')); }
function recentList() { return games.filter(g => g.lastPlayed).sort((a, b) => b.lastPlayed.localeCompare(a.lastPlayed)); }
function favList() { return games.filter(g => g.favorite).sort((a, b) => a.title.localeCompare(b.title, 'it')); }

function coverHTML(g) {
  if (!g.cover) return initial(g.title);
  return `<img src="${'file:///' + g.cover.replace(/\\/g, '/')}" alt="" onerror="this.remove()" />`;
}

function tile(g) {
  const el = document.createElement('div');
  el.className = 'tile';
  el.innerHTML = `<div class="cover">${coverHTML(g)}</div><div class="label"></div><div class="sub">${fmtTime(g.playMinutes)}${g.exe ? '' : ' · nessun .exe'}</div>`;
  el.querySelector('.label').textContent = g.title;
  el.onclick = () => openDetail(g.id);
  return el;
}

function fillRow(id, list) {
  const row = $(id);
  row.innerHTML = '';
  if (!list.length) { row.innerHTML = '<p class="muted">Nessun gioco qui ancora.</p>'; return; }
  list.forEach(g => row.appendChild(tile(g)));
}

function renderHome() {
  fillRow('shelf-recent', recentList().slice(0, 12));
  fillRow('shelf-fav', favList());
  fillRow('shelf-all', sortedAll().slice(0, 20));
}

function renderGrid(list, title) {
  $('grid-title').textContent = title;
  $('count').textContent = `${list.length} giochi`;
  const grid = $('grid');
  grid.innerHTML = '';
  if (!list.length) { grid.innerHTML = '<p class="muted">Nessun gioco. Aggiungi una cartella o importa uno zip.</p>'; return; }
  list.forEach(g => grid.appendChild(tile(g)));
}

function renderSide() {
  const box = $('side-list');
  box.innerHTML = '';
  for (const g of sortedAll()) {
    const b = document.createElement('button');
    b.className = 'side-item';
    b.textContent = g.title;
    b.onclick = () => openDetail(g.id);
    box.appendChild(b);
  }
}

function showView(name) {
  view = name;
  document.querySelectorAll('.side-item[data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === name));
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', (name === 'home' ? t.dataset.tab === 'home' : t.dataset.tab === 'library')));
  $('home-view').classList.toggle('hidden', name !== 'home');
  $('grid-view').classList.toggle('hidden', name === 'home');
  $('detail-view').classList.add('hidden');
  if (name === 'home') renderHome();
  else if (name === 'favorites') renderGrid(favList(), 'Preferiti');
  else if (name === 'recent') renderGrid(recentList(), 'Giocati di recente');
  else renderGrid(sortedAll(), 'Tutti i giochi');
}

function openDetail(id) {
  current = games.find(g => g.id === id);
  if (!current) return;
  $('home-view').classList.add('hidden');
  $('grid-view').classList.add('hidden');
  $('detail-view').classList.remove('hidden');
  $('d-cover').innerHTML = coverHTML(current) === initial(current.title) ? initial(current.title) : coverHTML(current);
  $('d-title').textContent = current.title;
  $('d-meta').textContent = `Tempo di gioco: ${fmtTime(current.playMinutes)} · Ultimo avvio: ${fmtDate(current.lastPlayed)}`;
  $('d-path').textContent = current.folder;
  $('d-fav').textContent = current.favorite ? '★ Nei preferiti' : '☆ Preferito';
  $('d-play').disabled = !current.exe;
  $('d-status').textContent = current.exe ? '' : 'Eseguibile non trovato nella cartella.';
}

function closeDetail() { current = null; showView(view); }

async function reload() {
  games = await window.blqk.list();
  renderSide();
  if (!$('detail-view').classList.contains('hidden')) return;
  showView(view);
}

async function addGame(promise) {
  const g = await promise;
  if (g) { await reload(); openDetail(g.id); }
}

document.querySelectorAll('.side-item[data-view]').forEach(b => b.onclick = () => { closeDetail(); showView(b.dataset.view); });
document.querySelectorAll('.tab').forEach(t => t.onclick = () => { closeDetail(); showView(t.dataset.tab === 'home' ? 'home' : 'all'); });
$('search').oninput = () => { if (view !== 'home' && $('detail-view').classList.contains('hidden')) showView(view === 'home' ? 'all' : view); };
$('btn-folder').onclick = () => addGame(window.blqk.addFolder());
$('btn-zip').onclick = () => addGame(window.blqk.importZip());
$('back').onclick = closeDetail;

$('d-play').onclick = async () => {
  const r = await window.blqk.play(current.id);
  $('d-status').textContent = r.ok ? 'Gioco avviato.' : r.error;
  if (r.ok) setTimeout(reload, 1000);
};
$('d-fav').onclick = async () => {
  await window.blqk.update(current.id, { favorite: !current.favorite });
  await reload(); openDetail(current.id);
};
$('d-cover-btn').onclick = async () => {
  const g = await window.blqk.setCover(current.id);
  if (g) { await reload(); openDetail(g.id); }
};
$('d-open').onclick = () => window.blqk.openFolder(current.id);
$('d-remove').onclick = async () => {
  if (!confirm('Rimuovere il gioco dalla libreria? I file non verranno cancellati.')) return;
  await window.blqk.remove(current.id);
  closeDetail(); await reload();
};

reload();
