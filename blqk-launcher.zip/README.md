# BLQK Launcher

Launcher di giochi per Windows, con tema nero/grigio/bianco Syntra.

## Funzioni
- Libreria con griglia di copertine e ricerca
- Aggiungi una cartella di gioco oppure importa uno zip (solo giochi che possiedi legalmente)
- Pagina di dettaglio: Gioca, preferiti, apri cartella, rimuovi dalla libreria
- Tempo di gioco e ultimo avvio salvati in locale

## Avvio in sviluppo (Windows)
```
npm install
npm start
```

## Installer
Su GitHub: Actions -> "Build BLQK Launcher (Windows)" -> Run workflow.
Scarica l'artefatto `BLQK-Launcher-Windows` (contiene `BLQK-Launcher-Setup-1.0.0.exe`).
Per una release, crea un tag `v1.0.0` e l'installer viene allegato automaticamente.

## Note
- I giochi restano dove sono; la libreria salva solo i percorsi.
- Lo zip importato viene estratto in `%APPDATA%/BLQK Launcher/games`.
