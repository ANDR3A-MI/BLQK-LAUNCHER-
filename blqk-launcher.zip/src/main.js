const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const AdmZip = require('adm-zip');

const DATA_FILE = () => path.join(app.getPath('userData'), 'library.json');
const GAMES_DIR = () => path.join(app.getPath('userData'), 'games');

function loadLibrary() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE(), 'utf8')); }
  catch { return { games: [] }; }
}
function saveLibrary(lib) {
  fs.mkdirSync(path.dirname(DATA_FILE()), { recursive: true });
  fs.writeFileSync(DATA_FILE(), JSON.stringify(lib, null, 2));
}

// Cerca il primo .exe utile dentro una cartella (ricorsivo, poco profondo)
function findExecutable(dir, depth = 0) {
  if (depth > 3) return null;
  let entries = [];
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return null; }
  const exes = entries.filter(e => e.isFile() && e.name.toLowerCase().endsWith('.exe'));
  const skip = /unins|setup|install|redist|vcredist|dxsetup|crash/i;
  const good = exes.find(e => !skip.test(e.name));
  if (good) return path.join(dir, good.name);
  for (const e of entries) {
    if (e.isDirectory()) {
      const found = findExecutable(path.join(dir, e.name), depth + 1);
      if (found) return found;
    }
  }
  return null;
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1200, height: 780, minWidth: 900, minHeight: 600,
    backgroundColor: '#0a0a0a',
    title: 'BLQK Launcher',
    icon: path.join(__dirname, 'renderer', 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

app.whenReady().then(() => {
  ipcMain.handle('library:list', () => loadLibrary().games);

  ipcMain.handle('library:addFolder', async () => {
    const r = await dialog.showOpenDialog({ properties: ['openDirectory'], title: 'Scegli la cartella del gioco' });
    if (r.canceled || !r.filePaths[0]) return null;
    const folder = r.filePaths[0];
    const exe = findExecutable(folder);
    const lib = loadLibrary();
    const game = {
      id: Date.now().toString(36),
      title: path.basename(folder),
      folder,
      exe,
      playMinutes: 0,
      lastPlayed: null,
      favorite: false,
    };
    lib.games.push(game);
    saveLibrary(lib);
    return game;
  });

  ipcMain.handle('library:importZip', async () => {
    const r = await dialog.showOpenDialog({
      properties: ['openFile'],
      filters: [{ name: 'Archivi zip', extensions: ['zip'] }],
      title: 'Scegli uno zip di un gioco che possiedi',
    });
    if (r.canceled || !r.filePaths[0]) return null;
    const zipPath = r.filePaths[0];
    const title = path.basename(zipPath, path.extname(zipPath));
    const id = Date.now().toString(36);
    const dest = path.join(GAMES_DIR(), id);
    fs.mkdirSync(dest, { recursive: true });
    new AdmZip(zipPath).extractAllTo(dest, true);
    const exe = findExecutable(dest);
    const lib = loadLibrary();
    const game = { id, title, folder: dest, exe, playMinutes: 0, lastPlayed: null, favorite: false };
    lib.games.push(game);
    saveLibrary(lib);
    return game;
  });

  ipcMain.handle('library:update', (_e, id, patch) => {
    const lib = loadLibrary();
    const g = lib.games.find(x => x.id === id);
    if (g) Object.assign(g, patch);
    saveLibrary(lib);
    return g || null;
  });

  ipcMain.handle('library:remove', (_e, id) => {
    const lib = loadLibrary();
    lib.games = lib.games.filter(x => x.id !== id);
    saveLibrary(lib);
    return true;
  });

  ipcMain.handle('game:play', (_e, id) => {
    const lib = loadLibrary();
    const g = lib.games.find(x => x.id === id);
    if (!g || !g.exe) return { ok: false, error: 'Eseguibile non trovato' };
    const started = Date.now();
    const child = spawn(g.exe, [], { cwd: path.dirname(g.exe), detached: true, stdio: 'ignore' });
    child.on('exit', () => {
      const l = loadLibrary();
      const gg = l.games.find(x => x.id === id);
      if (gg) {
        gg.playMinutes = (gg.playMinutes || 0) + Math.round((Date.now() - started) / 60000);
        saveLibrary(l);
      }
    });
    child.unref();
    const l2 = loadLibrary();
    const g2 = l2.games.find(x => x.id === id);
    if (g2) { g2.lastPlayed = new Date().toISOString(); saveLibrary(l2); }
    return { ok: true };
  });

  ipcMain.handle('game:openFolder', (_e, id) => {
    const g = loadLibrary().games.find(x => x.id === id);
    if (g) shell.openPath(g.folder);
    return true;
  });

  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
