const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('blqk', {
  list: () => ipcRenderer.invoke('library:list'),
  addFolder: () => ipcRenderer.invoke('library:addFolder'),
  importZip: () => ipcRenderer.invoke('library:importZip'),
  update: (id, patch) => ipcRenderer.invoke('library:update', id, patch),
  remove: (id) => ipcRenderer.invoke('library:remove', id),
  play: (id) => ipcRenderer.invoke('game:play', id),
  openFolder: (id) => ipcRenderer.invoke('game:openFolder', id),
});
