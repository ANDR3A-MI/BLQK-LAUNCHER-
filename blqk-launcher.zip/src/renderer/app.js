let games = [];
let view = 'library';
let current = null;

const $ = (id) => document.getElementById(id);

function fmtTime(min) {
  if (!min) return 'Mai giocato';
  const h = Math.floor(min / 60), m = min % 60;
  return h ? `${h} h ${m} min` : `${m} min`;
}
function fmtDate(iso) { return iso ? new Date(iso).toLocaleDateString('it-IT') : '—'; }

function visibleGames() {
  const q = $('search').value.trim().toLowerCase();
  let list = games.filter(g => g.title.toLowerCase().includes(q));
  if (view === 'favorites') list = list.filter(g => g.favorite);
  if (view === 'recent') list = list.filter(g => g.lastPlayed).sort((a, b) => b.lastPlayed.localeCompare(a.lastPlayed));
  else list = list.sort((a, b) => a.title.localeCompare(b.title, 'it'));
  return list;
}

function renderGrid() {
  const list = visibleGames();
  $('count').textContent = `${list.length} giochi`;
  const grid = $('grid-view');
  grid.innerHTML = '';
  if (!list.length) {
    grid.innerHTML = '<p class="muted">Nessun gioco. Usa "Aggiungi cartella" o "Importa zip" nella barra laterale.</p>';
    return;
  }
  for (const g of list) {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="cover">${g.title.charAt(0).toUpperCase()}</div>
      <div class="label"></div>
      <div class="sub">${fmtTime(g.playMinutes)}${g.exe ? '' : ' · eseguibile non trovato'}</div>`;
    card.querySelector('.label').textContent = g.title;
    card.onclick = () => openDetail(g.id);
    grid.appendChild(card);
  }
}

function openDetail(id) {
  current = games.find(g => g.id === id);
  if (!current) return;
  $('grid-view').classList.add('hidden');
  $('detail-view').classList.remove('hidden');
  $('d-cover').textContent = current.title.charAt(0).toUpperCase();
  $('d-title').textContent = current.title;
  $('d-meta').textContent = `Tempo di gioco: ${fmtTime(current.playMinutes)} · Ultimo avvio: ${fmtDate(current.lastPlayed)}`;
  $('d-path').textContent = current.folder;
  $('d-fav').textContent = current.favorite ? '★ Nei preferiti' : '☆ Preferito';
  $('d-play').disabled = !current.exe;
  $('d-status').textContent = current.exe ? '' : 'Eseguibile non trovato nella cartella.';
}

function closeDetail() {
  current = null;
  $('detail-view').classList.add('hidden');
  $('grid-view').classList.remove('hidden');
}

async function reload() {
  games = await window.blqk.list();
  renderGrid();
}

async function addGame(promise) {
  const g = await promise;
  if (g) { await reload(); openDetail(g.id); }
}

document.querySelectorAll('.nav').forEach(btn => btn.onclick = () => {
  document.querySelectorAll('.nav').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  view = btn.dataset.view;
  closeDetail();
  renderGrid();
});

$('search').oninput = () => { closeDetail(); renderGrid(); };
$('btn-folder').onclick = () => addGame(window.blqk.addFolder());
$('btn-zip').onclick = () => addGame(window.blqk.importZip());
$('back').onclick = closeDetail;

$('d-play').onclick = async () => {
  const r = await window.blqk.play(current.id);
  $('d-status').textContent = r.ok ? 'Gioco avviato.' : r.error;
  if (r.ok) setTimeout(reload, 1000);
};
$('d-fav').onclick = async () => {
  await window.blqk.update(current.id, { favorite: !current.favorite });
  await reload(); openDetail(current.id);
};
$('d-open').onclick = () => window.blqk.openFolder(current.id);
$('d-remove').onclick = async () => {
  if (!confirm('Rimuovere il gioco dalla libreria? I file non verranno cancellati.')) return;
  await window.blqk.remove(current.id);
  closeDetail(); await reload();
};

reload();
